# QRScanner-App
QR code scanner mobile application that implements ML Kit's Barcode Scanning API for Firebase. The application allows
a user to scan any QR code, see the corresponding link and visit the corresponding website from the app.

To run the app, download the generated apk and the app should run on your mobile device.
