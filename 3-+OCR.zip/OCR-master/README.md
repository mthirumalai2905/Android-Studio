# OCR
This is a simple OCR application which can take photos from your local storage and convert the text in image into text view and read those text. I use firebase ML Kit for image to text recognition.

![Screenshot](https://user-images.githubusercontent.com/35846452/127677883-70a46dbb-8d92-4bca-8fd2-850b0f26633a.jpg)

# Screen Record
https://user-images.githubusercontent.com/35846452/127678272-7a95d46c-a219-4ff4-9dba-d19add386326.mp4
